<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IMAGUESS // PERFIL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=VT323&display=swap" rel="stylesheet">
    <style>
        :root {
            --green: #00ff41;
            --green-dim: #00b32c;
            --green-glow: rgba(0,255,65,0.15);
            --red: #ff0040;
            --bg: #0a0a0a;
        }
        * { box-sizing: border-box; }
        body {
            background: var(--bg);
            font-family: 'Share Tech Mono', monospace;
            color: var(--green);
            min-height: 100vh;
            position: relative;
        }
        body::before {
            content: '';
            position: fixed; inset: 0;
            background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.12) 2px, rgba(0,0,0,0.12) 4px);
            pointer-events: none; z-index: 100;
        }
        body::after {
            content: '';
            position: fixed; inset: 0;
            background: radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.65) 100%);
            pointer-events: none; z-index: 99;
        }
        #matrix-canvas {
            position: fixed; top:0; left:0; width:100%; height:100%;
            opacity: 0.04; z-index: 0;
        }
        .scanline-move {
            position: fixed; width:100%; height:3px;
            background: linear-gradient(transparent, rgba(0,255,65,0.06), transparent);
            animation: scanline 7s linear infinite;
            pointer-events: none; z-index: 101;
        }
        @keyframes scanline { 0%{top:-4px;} 100%{top:100vh;} }

        /* Navbar */
        .navbar {
            position: fixed; top:0; left:0; right:0; z-index:50;
            background: rgba(0,0,0,0.9);
            border-bottom: 1px solid rgba(0,255,65,0.2);
            padding: 12px 32px;
            display: flex; align-items:center; justify-content:space-between;
        }
        .nav-logo { font-family:'VT323',monospace; font-size:1.8rem; color:var(--green); text-shadow:0 0 10px var(--green); }
        .nav-link {
            color: var(--green-dim); text-decoration:none;
            font-size:0.75rem; letter-spacing:2px;
            transition:color 0.2s; padding:4px 8px;
            border:1px solid transparent;
        }
        .nav-link:hover { color:var(--green); border-color:rgba(0,255,65,0.3); }

        /* Terminal box */
        .t-box {
            border: 1px solid var(--green-dim);
            box-shadow: 0 0 20px var(--green-glow), inset 0 0 20px rgba(0,255,65,0.02);
            background: rgba(0,10,2,0.92);
            position: relative;
        }
        .corner { position:absolute; width:12px; height:12px; border-color:var(--green); border-style:solid; }
        .corner-tl { top:-1px; left:-1px; border-width:1px 0 0 1px; }
        .corner-tr { top:-1px; right:-1px; border-width:1px 1px 0 0; }
        .corner-bl { bottom:-1px; left:-1px; border-width:0 0 1px 1px; }
        .corner-br { bottom:-1px; right:-1px; border-width:0 1px 1px 0; }

        /* Avatar */
        .avatar-ring {
            width: 96px; height: 96px;
            border: 2px solid var(--green);
            border-radius: 2px;
            display: flex; align-items:center; justify-content:center;
            background: rgba(0,255,65,0.04);
            box-shadow: 0 0 20px var(--green-glow);
            position: relative;
            flex-shrink: 0;
        }
        .avatar-ring::before {
            content: '';
            position:absolute; inset:-6px;
            border: 1px solid rgba(0,255,65,0.2);
            border-radius: 2px;
            animation: rotate 8s linear infinite;
        }
        @keyframes rotate { to { transform: rotate(360deg); } }
        .avatar-letter {
            font-family: 'VT323', monospace;
            font-size: 3.5rem;
            color: var(--green);
            text-shadow: 0 0 20px var(--green);
            line-height: 1;
        }

        /* Form fields */
        .field-label {
            font-size: 0.65rem; color: var(--green-dim);
            letter-spacing: 3px; text-transform: uppercase;
            margin-bottom: 6px;
        }
        .field-value {
            font-size: 0.9rem; color: var(--green);
            padding: 10px 14px;
            border: 1px solid rgba(0,255,65,0.2);
            background: rgba(0,255,65,0.03);
            letter-spacing: 1px;
        }
        .field-input {
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--green-dim);
            color: var(--green);
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.9rem;
            outline: none;
            width: 100%;
            padding: 8px 4px;
            letter-spacing: 1px;
            transition: border-color 0.2s;
            caret-color: var(--green);
        }
        .field-input:focus { border-bottom-color: var(--green); }
        .field-input::placeholder { color: #1a5c29; }

        /* Save button */
        .save-btn {
            background: transparent;
            border: 1px solid var(--green);
            color: var(--green);
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.85rem;
            padding: 10px 28px;
            cursor: pointer;
            letter-spacing: 2px;
            transition: all 0.2s;
            position: relative; overflow: hidden;
        }
        .save-btn::before {
            content: ''; position:absolute; inset:0;
            background: var(--green); transform:translateX(-100%);
            transition:transform 0.2s; z-index:-1;
        }
        .save-btn:hover { color:#000; }
        .save-btn:hover::before { transform:translateX(0); }

        /* Danger button */
        .danger-btn {
            background: transparent;
            border: 1px solid rgba(255,0,64,0.4);
            color: rgba(255,0,64,0.6);
            font-family: 'Share Tech Mono', monospace;
            font-size: 0.75rem;
            padding: 8px 20px;
            cursor: pointer;
            letter-spacing: 2px;
            transition: all 0.2s;
        }
        .danger-btn:hover { border-color:var(--red); color:var(--red); box-shadow:0 0 12px rgba(255,0,64,0.2); }

        /* Stat cards */
        .stat-card {
            border: 1px solid rgba(0,255,65,0.2);
            background: rgba(0,255,65,0.03);
            padding: 16px;
            text-align: center;
        }
        .stat-num { font-family:'VT323',monospace; font-size:2.2rem; color:var(--green); line-height:1; }
        .stat-lbl { font-size:0.6rem; color:var(--green-dim); letter-spacing:2px; margin-top:4px; }

        /* History rows */
        .hist-row {
            display:flex; align-items:center; justify-content:space-between;
            padding:10px 16px;
            border-bottom:1px solid rgba(0,255,65,0.06);
            font-size:0.75rem;
            transition:background 0.15s;
        }
        .hist-row:last-child { border-bottom:none; }
        .hist-row:hover { background:rgba(0,255,65,0.03); }

        /* Section title */
        .section-title {
            font-size:0.65rem; color:var(--green-dim);
            letter-spacing:3px; margin-bottom:16px;
        }

        /* Toggle switch */
        .toggle-wrap {
            display:flex; align-items:center; justify-content:space-between;
            padding:12px 0;
            border-bottom:1px solid rgba(0,255,65,0.08);
        }
        .toggle-wrap:last-child { border-bottom:none; }
        .toggle-label { font-size:0.8rem; color:var(--green-dim); }
        .toggle-desc { font-size:0.65rem; color:#1a5c29; margin-top:2px; }
        .toggle {
            position:relative; width:44px; height:22px;
            background:rgba(0,255,65,0.1);
            border:1px solid rgba(0,255,65,0.3);
            border-radius:2px;
            cursor:pointer;
            transition:all 0.2s;
            flex-shrink:0;
        }
        .toggle.on { background:rgba(0,255,65,0.2); border-color:var(--green); }
        .toggle::after {
            content:''; position:absolute; top:3px; left:3px;
            width:14px; height:14px;
            background:rgba(0,255,65,0.4);
            transition:all 0.2s;
        }
        .toggle.on::after { left:23px; background:var(--green); box-shadow:0 0 6px var(--green); }

        .blink { animation:blink 1s step-end infinite; }
        @keyframes blink { 50%{opacity:0;} }

        /* Alert */
        .alert-success {
            border:1px solid var(--green-dim);
            background:rgba(0,255,65,0.05);
            color:var(--green);
            padding:8px 14px;
            font-size:0.75rem;
            letter-spacing:1px;
            margin-bottom:16px;
            display:none;
        }
        .alert-success.show { display:block; }

        /* Badge */
        .badge {
            display:inline-block;
            border:1px solid rgba(0,255,65,0.3);
            color:var(--green-dim);
            font-size:0.6rem;
            padding:2px 8px;
            letter-spacing:1px;
            margin-right:4px;
            margin-bottom:4px;
        }
        .badge.earned { border-color:var(--green); color:var(--green); background:rgba(0,255,65,0.06); }
    </style>
</head>
<body>
    <div class="scanline-move"></div>
    <canvas id="matrix-canvas"></canvas>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-logo">IMAGUESS</div>
        <div style="display:flex;gap:8px;align-items:center;">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">&lt; DASHBOARD</a>
            <a href="<?php echo e(route('game')); ?>" class="nav-link">▶ JUGAR</a>
            <a href="<?php echo e(route('ranking')); ?>" class="nav-link">LEADERBOARD</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin:0;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background:transparent;border:1px solid rgba(255,0,64,0.4);color:rgba(255,0,64,0.6);font-family:'Share Tech Mono',monospace;font-size:0.75rem;padding:4px 12px;cursor:pointer;letter-spacing:2px;transition:all 0.2s;"
                        onmouseover="this.style.borderColor='#ff0040';this.style.color='#ff0040'"
                        onmouseout="this.style.borderColor='rgba(255,0,64,0.4)';this.style.color='rgba(255,0,64,0.6)'">
                    ⏻ SALIR
                </button>
            </form>
        </div>
    </nav>

    <div style="position:relative;z-index:10;padding-top:72px;max-width:800px;margin:0 auto;padding-left:16px;padding-right:16px;padding-bottom:60px;">

        <!-- Page header -->
        <div style="padding-top:28px;margin-bottom:32px;">
            <div style="font-size:0.65rem;color:var(--green-dim);letter-spacing:3px;margin-bottom:4px;">
                &gt; SISTEMA // PERFIL_USUARIO
            </div>
            <div style="font-family:'VT323',monospace;font-size:2.5rem;color:var(--green);text-shadow:0 0 12px rgba(0,255,65,0.3);">
                CONFIGURACIÓN
            </div>
        </div>

        <?php if(session('status')): ?>
        <div class="alert-success show">
            [OK] <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>

        <!-- TOP: Avatar + info + stats -->
        <div style="display:grid;grid-template-columns:auto 1fr;gap:24px;align-items:start;margin-bottom:24px;">

            <!-- Avatar -->
            <div class="avatar-ring">
                <div class="avatar-letter">
                    <?php echo e(strtoupper(substr(auth()->user()->name ?? 'U', 0, 1))); ?>

                </div>
            </div>

            <!-- Info block -->
            <div class="t-box" style="padding:20px;">
                <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
                <div class="corner corner-bl"></div><div class="corner corner-br"></div>

                <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                    <div>
                        <div style="font-family:'VT323',monospace;font-size:2rem;color:var(--green);text-shadow:0 0 10px rgba(0,255,65,0.3);line-height:1;">
                            <?php echo e(strtoupper(auth()->user()->name ?? 'USUARIO')); ?>

                        </div>
                        <div style="font-size:0.7rem;color:var(--green-dim);margin-top:4px;letter-spacing:1px;">
                            <?php echo e(auth()->user()->email ?? 'correo@ejemplo.com'); ?>

                        </div>
                        <div style="font-size:0.65rem;color:#1a5c29;margin-top:6px;letter-spacing:2px;">
                            MIEMBRO DESDE <?php echo e(auth()->user()->created_at?->format('M Y') ?? 'ENERO 2025'); ?>

                        </div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:0.6rem;color:#1a5c29;letter-spacing:2px;margin-bottom:4px;">ESTADO</div>
                        <div style="display:flex;align-items:center;gap:6px;justify-content:flex-end;">
                            <div style="width:6px;height:6px;border-radius:50%;background:var(--green);box-shadow:0 0 6px var(--green);animation:pulse 2s ease-in-out infinite;"></div>
                            <span style="font-size:0.75rem;color:var(--green);">ACTIVO</span>
                        </div>
                        <div style="font-size:0.65rem;color:#1a5c29;margin-top:6px;">
                            RANK GLOBAL: <span style="color:var(--green-dim);">#<?php echo e(auth()->user()->globalRank() ?? '—'); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Mini stats -->
                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:16px;">
                    <div class="stat-card">
                        <div class="stat-num"><?php echo e(auth()->user()->scores()->max('points') ?? 0); ?></div>
                        <div class="stat-lbl">RÉCORD</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-num"><?php echo e(auth()->user()->scores()->count() ?? 0); ?></div>
                        <div class="stat-lbl">PARTIDAS</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-num"><?php echo e(auth()->user()->scores()->avg('points') ? round(auth()->user()->scores()->avg('points')) : 0); ?></div>
                        <div class="stat-lbl">MEDIA</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Two column layout -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">

            <!-- Edit name -->
            <div class="t-box" style="padding:20px;">
                <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
                <div class="corner corner-bl"></div><div class="corner corner-br"></div>
                <div class="section-title">&gt; DATOS_DE_CUENTA</div>

                <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div style="margin-bottom:20px;">
                        <div class="field-label">&gt; NOMBRE DE USUARIO</div>
                        <input type="text" name="name" class="field-input"
                               value="<?php echo e(auth()->user()->name ?? ''); ?>"
                               placeholder="tu_nombre">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:var(--red);font-size:0.65rem;margin-top:4px;">[ERR] <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div style="margin-bottom:24px;">
                        <div class="field-label">&gt; EMAIL</div>
                        <input type="email" name="email" class="field-input"
                               value="<?php echo e(auth()->user()->email ?? ''); ?>"
                               placeholder="correo@ejemplo.com">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:var(--red);font-size:0.65rem;margin-top:4px;">[ERR] <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="save-btn">GUARDAR</button>
                </form>
            </div>

            <!-- Change password -->
            <div class="t-box" style="padding:20px;">
                <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
                <div class="corner corner-bl"></div><div class="corner corner-br"></div>
                <div class="section-title">&gt; CAMBIAR_CONTRASEÑA</div>

                <form method="POST" action="<?php echo e(route('password.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div style="margin-bottom:16px;">
                        <div class="field-label">&gt; CONTRASEÑA ACTUAL</div>
                        <input type="password" name="current_password" class="field-input" placeholder="••••••••">
                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:var(--red);font-size:0.65rem;margin-top:4px;">[ERR] <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div style="margin-bottom:16px;">
                        <div class="field-label">&gt; NUEVA CONTRASEÑA</div>
                        <input type="password" name="password" class="field-input" placeholder="••••••••">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color:var(--red);font-size:0.65rem;margin-top:4px;">[ERR] <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div style="margin-bottom:24px;">
                        <div class="field-label">&gt; CONFIRMAR</div>
                        <input type="password" name="password_confirmation" class="field-input" placeholder="••••••••">
                    </div>

                    <button type="submit" class="save-btn">ACTUALIZAR</button>
                </form>
            </div>
        </div>

        <!-- Preferences + History row -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">

            <!-- Preferences (expandable in future) -->
            <div class="t-box" style="padding:20px;">
                <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
                <div class="corner corner-bl"></div><div class="corner corner-br"></div>
                <div class="section-title">&gt; PREFERENCIAS</div>

                <div class="toggle-wrap">
                    <div>
                        <div class="toggle-label">SONIDO</div>
                        <div class="toggle-desc">Efectos de sonido en partida</div>
                    </div>
                    <div class="toggle on" onclick="this.classList.toggle('on')" title="Próximamente"></div>
                </div>
                <div class="toggle-wrap">
                    <div>
                        <div class="toggle-label">ANIMACIONES</div>
                        <div class="toggle-desc">Lluvia de fondo Matrix</div>
                    </div>
                    <div class="toggle on" onclick="this.classList.toggle('on')" title="Próximamente"></div>
                </div>
                <div class="toggle-wrap">
                    <div>
                        <div class="toggle-label">PISTAS AUTOMÁTICAS</div>
                        <div class="toggle-desc">Pista al fallar 3 veces</div>
                    </div>
                    <div class="toggle" onclick="this.classList.toggle('on')" title="Próximamente"></div>
                </div>
                <div class="toggle-wrap">
                    <div>
                        <div class="toggle-label">APARECER EN RANKING</div>
                        <div class="toggle-desc">Mostrar tu puntuación públicamente</div>
                    </div>
                    <div class="toggle on" onclick="this.classList.toggle('on')" title="Próximamente"></div>
                </div>

                <div style="margin-top:14px;font-size:0.6rem;color:#1a5c29;letter-spacing:1px;">
                    * Configuración guardable próximamente
                </div>
            </div>

            <!-- Score history -->
            <div class="t-box" style="padding:20px;">
                <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
                <div class="corner corner-bl"></div><div class="corner corner-br"></div>
                <div class="section-title">&gt; ÚLTIMAS_PARTIDAS</div>

                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->scores()->latest()->take(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="hist-row">
                    <span style="color:#1a5c29;font-size:0.65rem;"><?php echo e($score->created_at->format('d/m/y H:i')); ?></span>
                    <span style="font-family:'VT323',monospace;font-size:1.3rem;color:var(--green);">
                        <?php echo e($score->points); ?> <span style="font-size:0.7rem;color:var(--green-dim);">PTS</span>
                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div style="padding:20px 0;text-align:center;color:#1a5c29;font-size:0.75rem;letter-spacing:2px;">
                    SIN PARTIDAS AÚN
                </div>
                <?php endif; ?>

                <a href="<?php echo e(route('ranking')); ?>" style="display:block;margin-top:10px;font-size:0.65rem;color:var(--green-dim);text-decoration:none;letter-spacing:1px;transition:color 0.2s;"
                   onmouseover="this.style.color='var(--green)'" onmouseout="this.style.color='var(--green-dim)'">
                    &gt; VER LEADERBOARD →
                </a>
            </div>
        </div>

        <!-- Badges section (placeholder for future) -->
        <div class="t-box" style="padding:20px;margin-bottom:16px;">
            <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
            <div class="corner corner-bl"></div><div class="corner corner-br"></div>
            <div class="section-title">&gt; LOGROS — PRÓXIMAMENTE</div>
            <div>
                <span class="badge earned">PRIMERA PARTIDA</span>
                <span class="badge earned">10 IMÁGENES ACERTADAS</span>
                <span class="badge">50 IMÁGENES</span>
                <span class="badge">PUNTUACIÓN 500+</span>
                <span class="badge">SIN PISTAS</span>
                <span class="badge">PARTIDA PERFECTA</span>
            </div>
        </div>

        <!-- Danger zone -->
        <div class="t-box" style="padding:20px;border-color:rgba(255,0,64,0.25);">
            <div class="corner corner-tl" style="border-color:rgba(255,0,64,0.5);"></div>
            <div class="corner corner-tr" style="border-color:rgba(255,0,64,0.5);"></div>
            <div class="corner corner-bl" style="border-color:rgba(255,0,64,0.5);"></div>
            <div class="corner corner-br" style="border-color:rgba(255,0,64,0.5);"></div>
            <div style="font-size:0.65rem;color:rgba(255,0,64,0.5);letter-spacing:3px;margin-bottom:12px;">
                &gt; ZONA_PELIGROSA
            </div>
            <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
                <div>
                    <div style="font-size:0.8rem;color:rgba(255,0,64,0.6);">ELIMINAR CUENTA</div>
                    <div style="font-size:0.65rem;color:#1a5c29;margin-top:2px;">Esta acción es irreversible. Se borrarán todos tus datos.</div>
                </div>
                <button class="danger-btn" onclick="confirmDelete()">ELIMINAR CUENTA</button>
            </div>
        </div>

        <!-- Footer -->
        <div style="margin-top:40px;text-align:center;font-size:0.6rem;color:#1a5c29;letter-spacing:3px;">
            IMAGUESS v1.0 &nbsp;|&nbsp; TUS DATOS SON PRIVADOS
        </div>
    </div>

    <!-- Delete confirmation modal -->
    <div id="delete-modal" style="display:none;position:fixed;inset:0;z-index:300;background:rgba(0,0,0,0.92);align-items:center;justify-content:center;">
        <div class="t-box" style="padding:32px;max-width:360px;width:90%;text-align:center;">
            <div class="corner corner-tl"></div><div class="corner corner-tr"></div>
            <div class="corner corner-bl"></div><div class="corner corner-br"></div>
            <div style="font-size:0.65rem;color:var(--red);letter-spacing:3px;margin-bottom:16px;">[ADVERTENCIA]</div>
            <div style="font-family:'VT323',monospace;font-size:1.8rem;color:var(--red);margin-bottom:12px;">¿CONFIRMAR BORRADO?</div>
            <div style="font-size:0.75rem;color:var(--green-dim);margin-bottom:24px;line-height:1.6;">
                Se eliminarán permanentemente tu cuenta,<br>puntuaciones e historial de partidas.
            </div>
            <form method="POST" action="<?php echo e(route('profile.destroy')); ?>" style="display:inline;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="danger-btn" style="margin-right:12px;">SÍ, ELIMINAR</button>
            </form>
            <button class="save-btn" onclick="document.getElementById('delete-modal').style.display='none'">CANCELAR</button>
        </div>
    </div>

    <script>
        function confirmDelete() {
            document.getElementById('delete-modal').style.display = 'flex';
        }

        // Matrix background
        const canvas = document.getElementById('matrix-canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth; canvas.height = window.innerHeight;
        const cols = Math.floor(canvas.width / 16);
        const drops = Array(cols).fill(1);
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%^&*()アイウエオ';
        function drawMatrix() {
            ctx.fillStyle='rgba(0,0,0,0.05)'; ctx.fillRect(0,0,canvas.width,canvas.height);
            ctx.fillStyle='#00ff41'; ctx.font='14px Share Tech Mono';
            drops.forEach((y,i) => {
                ctx.fillText(chars[Math.floor(Math.random()*chars.length)],i*16,y*16);
                if(y*16>canvas.height && Math.random()>0.975) drops[i]=0;
                drops[i]++;
            });
        }
        setInterval(drawMatrix, 50);

        @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:0.3;} }
    </script>
    <style>
        @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:0.3;} }
    </style>
</body>
</html>
<?php /**PATH C:\Users\3bmar\Proyectos\Imaguess\resources\views/profile/edit.blade.php ENDPATH**/ ?>